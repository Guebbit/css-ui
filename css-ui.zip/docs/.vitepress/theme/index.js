import DefaultTheme from "vitepress/theme";

export default {
    ...DefaultTheme,
    enhanceApp({ app }) {
        // Custom enhancements for your app go here
    }
}