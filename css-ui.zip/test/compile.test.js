import { describe, it } from "mocha";
import { expect } from "chai";
import fs from "fs";
import util from "util";
import * as sass from "sass";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let cssCompiled;

function sassCompiler(){
    return util.promisify(sass.render)({
        includePaths: ['./scss', './node_modules'],
        file: path.join(__dirname, './test.scss'),
        // outputStyle: 'compressed'
    })
        .then(result => result?.css?.toString());
}

describe("COMPILE", function() {
    // to remove timeout error
    this.timeout(10000);

    it('Should compile', async function() {
        cssCompiled = await sassCompiler();
        // Not necessary, but let's compile the file
        fs.writeFile(path.join(__dirname, 'test.css'), cssCompiled, () => {});
    });

    it('Check some rules', function() {
        // TODO
        expect(cssCompiled).to.contain('--');
    });
});